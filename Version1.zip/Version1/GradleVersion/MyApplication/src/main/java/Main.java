public class Main {
    public static void main(String[] args) {
        MyLibraryClass myLibraryClass = new MyLibraryClass();
        System.out.println("My application:");
        myLibraryClass.myLibraryMethod();
    }
}
