import org.javatuples.Pair;

public class MyLibraryClassGradle {
    public void myLibraryMethod () {
        Pair pair = new Pair(0, 1);
        System.out.println(pair.getValue(0));
    }

    public static void main(String[] args) {
        MyLibraryClassGradle myLibraryClass = new MyLibraryClassGradle();
        myLibraryClass.myLibraryMethod();
    }
}
